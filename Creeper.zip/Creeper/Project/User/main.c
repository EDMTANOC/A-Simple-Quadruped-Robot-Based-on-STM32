#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "Serial.h"
#include "Move.h"

uint16_t Data1;//定义接收变量
int main(void)
{
	/*模块初始化*/	
	Move_Init();		//移动初始化
	Serial_Init();		//舵机初始化

	
	
	while (1)
	{
			
	}
}
	void USART1_IRQHandler(void)
{
	if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)
	{
		Data1=USART_ReceiveData(USART1);
		if(Data1==0x30)Move_Stop();//启动
		if(Data1==0x31)Go_Ahead();//前进
		if(Data1==0x32)Go_Back();//后退
		if(Data1==0x37)Turn_Left();//左转
		if(Data1==0x34)Turn_Right();//右转
		if(Data1==0x35)Turn_Dead();//趴下
		if(Data1==0x36)Turn_Dancing();//跳舞
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);
	}
}
