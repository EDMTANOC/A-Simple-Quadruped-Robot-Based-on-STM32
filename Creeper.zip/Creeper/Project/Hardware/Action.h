#ifndef __ACTION_H
#define __ACTION_H
void leg0_Init(void);
void leg1_Init(void);
void leg2_Init(void);
void leg3_Init(void);
//以上为单足初始化

void leg0_Straight(void);
void leg1_Straight(void);
void leg2_Straight(void);
void leg3_Straight(void);
//以上为单腿伸直

void leg0_ATCW(void);
void leg1_ATCW(void);
void leg2_ATCW(void);
void leg3_ATCW(void);
//以上为单足逆时针迈进

void leg0_CW(void);
void leg1_CW(void);
void leg2_CW(void);
void leg3_CW(void);
//以上为单足顺时针迈进
#endif
