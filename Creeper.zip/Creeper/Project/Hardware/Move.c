#include "stm32f10x.h"                  // Device header
#include "Servo.h"
#include "Delay.h"
#include "Action.h"
void Move_Init(void){
	Servo_Init();//舵机初始化
}
void Go_Ahead(void){
	leg0_CW();
	leg2_ATCW();
	Delay_ms(200);//0,2号腿各自挪动
	
	Servo4_SetAngle(110);
	Servo6_SetAngle(120);
	leg3_CW();
	leg1_ATCW();
	Delay_ms(200);//0,2号腿转向舵机反向推动的同时1,3号腿挪动
	
	Servo5_SetAngle(60);
	Servo7_SetAngle(50);	
	leg0_CW();
	leg2_ATCW();
	Delay_ms(200);//1,3号腿转向舵机反向推动的同时0,2号腿挪动
	
	Servo4_SetAngle(110);
	Servo6_SetAngle(120);
	leg3_CW();
	leg1_ATCW();
	Delay_ms(200);
	
	Servo5_SetAngle(60);
	Servo7_SetAngle(50);	
	leg0_CW();
	leg2_ATCW();
	Delay_ms(200);//重复步态

	Servo4_SetAngle(110);
	Servo6_SetAngle(120);
	leg3_CW();
	leg1_ATCW();
	Delay_ms(200);
	
	Servo5_SetAngle(60);
	Servo7_SetAngle(50);	
	leg0_CW();
	leg2_ATCW();
	Delay_ms(200);//重复步态
	
	leg0_Init();
	leg1_Init();
	leg2_Init();
	leg3_Init();//调整
	
	
}
void Go_Back(void){
	leg0_ATCW();
	leg2_CW();
	Delay_ms(200);//0,2号腿各自挪动
	
	Servo4_SetAngle(110);
	Servo6_SetAngle(120);
	leg3_ATCW();
	leg1_CW();
	Delay_ms(200);//0,2号腿转向舵机反向推动的同时1,3号腿挪动
	
	Servo5_SetAngle(60);
	Servo7_SetAngle(50);	
	leg0_ATCW();
	leg2_CW();
	Delay_ms(200);//1,3号腿转向舵机反向推动的同时0,2号腿挪动
	
	Servo4_SetAngle(110);
	Servo6_SetAngle(120);
	leg3_ATCW();
	leg1_CW();
	Delay_ms(200);
	
	Servo5_SetAngle(60);
	Servo7_SetAngle(50);	
	leg0_ATCW();
	leg2_CW();
	Delay_ms(200);//重复步态
	
	leg0_Init();
	leg1_Init();
	leg2_Init();
	leg3_Init();//调整
}
void Turn_Left(void){
	leg0_ATCW();
	Delay_ms(50);
	leg2_ATCW();
	Delay_ms(50);
	leg1_ATCW();
	Delay_ms(50);
	leg3_ATCW();
	Delay_ms(100);//四足逆时针转
	Servo4_SetAngle(65);
	Servo5_SetAngle(25);
	Servo6_SetAngle(75);
	Servo7_SetAngle(12);//转向舵机顺时针转动使机身向左转动
	Delay_ms(100);
	leg0_ATCW();
	leg1_ATCW();
	Delay_ms(100);
	leg2_ATCW();
	leg3_ATCW();
	Delay_ms(100);
	Servo4_SetAngle(65);
	Servo5_SetAngle(25);
	Servo6_SetAngle(75);
	Servo7_SetAngle(12);
	Delay_ms(50);
	leg0_Init();
	leg1_Init();
	leg2_Init();
	leg3_Init();

}
void Turn_Right(void){
	leg0_CW();
	Delay_ms(50);
	leg2_CW();
	Delay_ms(50);
	leg1_CW();
	Delay_ms(50);
	leg3_CW();
	Delay_ms(100);//四足顺时针转
	Servo4_SetAngle(145);
	Servo5_SetAngle(105);
	Servo6_SetAngle(165);
	Servo7_SetAngle(100);//转向舵机逆时针转动使机身向右转动
	Delay_ms(100);
	leg0_CW();
	leg1_CW();
	Delay_ms(100);
	leg2_CW();
	leg3_CW();
	Delay_ms(100);
	Servo4_SetAngle(145);
	Servo5_SetAngle(105);
	Servo6_SetAngle(165);
	Servo7_SetAngle(100);
	Delay_ms(50);
	leg0_Init();
	leg1_Init();
	leg2_Init();
	leg3_Init();

}
void Move_Stop(void){
	leg0_Init();
	leg1_Init();
	leg2_Init();
	leg3_Init();
}
void Turn_Dead(void){
	leg0_Straight();
	Delay_ms(50);
	leg1_Straight();
	Delay_ms(50);
	leg2_Straight();
	Delay_ms(50);
	leg3_Straight();
	Delay_ms(50);

}
void Turn_Dancing(void){
	leg0_CW();
	Delay_ms (50);
	leg1_ATCW();
	Delay_ms (50);
	leg2_CW();
	Delay_ms (50);
	leg3_ATCW();
	/*Servo4_SetAngle(90);//0腿顺时针到90？
	Servo5_SetAngle(105);//1腿逆时针到90
	Servo6_SetAngle(74);//2腿顺时针到90
	Servo7_SetAngle(102);//3腿逆时针到90*/
	
	/*Servo4_SetAngle(145);//0腿逆时针到90
	Servo5_SetAngle(25);//1腿顺时针到90
	Servo6_SetAngle(165);//2腿逆时针到90
	Servo7_SetAngle(12);//3腿顺时针到90*/
	
	Delay_ms(400);
	Servo0_SetAngle(60);
	Servo1_SetAngle(120);
	Servo2_SetAngle(60);
	Servo3_SetAngle(120);
	Delay_ms(400);
	Servo0_SetAngle(100);//右
	Servo1_SetAngle(160);
	Servo2_SetAngle(20);
	Servo3_SetAngle(80);
	Delay_ms(500);	
	Servo0_SetAngle(20);//左
	Servo1_SetAngle(80);
	Servo2_SetAngle(100);
	Servo3_SetAngle(160);
	Delay_ms(500);
	Servo0_SetAngle(100);//右
	Servo1_SetAngle(160);
	Servo2_SetAngle(20);
	Servo3_SetAngle(80);
	Delay_ms(500);	
	Servo0_SetAngle(20);//左
	Servo1_SetAngle(80);
	Servo2_SetAngle(100);
	Servo3_SetAngle(160);
	Delay_ms(500);
	leg0_Init();
	leg1_Init();
	leg2_Init();
	leg3_Init();
	
}
