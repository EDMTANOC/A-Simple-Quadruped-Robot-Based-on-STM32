#ifndef __MOVE_H
#define __MOVE_H
void Move_Init(void);
void Turn_Right(void);
void Turn_Left(void);
void Go_Back(void);
void Go_Ahead(void);
void Move_Stop(void);
void Turn_Dead(void);
void Turn_Dancing(void);
#endif
