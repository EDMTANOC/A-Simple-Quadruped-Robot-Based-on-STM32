#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Servo.h"

void leg0_Init(void)
{	
	Servo0_SetAngle(55);
	Delay_ms(100);
	Servo4_SetAngle(110);
	
}
void leg1_Init(void)
{	
	Servo1_SetAngle(105);
	Delay_ms(100);
	Servo5_SetAngle(60);
	
}
void leg2_Init(void)
{
	Servo2_SetAngle(70);
	Delay_ms(100);
	Servo6_SetAngle(120);
	
}
void leg3_Init(void)
{
	Servo3_SetAngle(105);
	Delay_ms(100);
	Servo7_SetAngle(50);
	
}
//以上为单足初始化

void leg0_Straight(void)
{
	Servo4_SetAngle(110);
	Delay_ms(100);
	Servo0_SetAngle(110);
}
void leg1_Straight(void)
{
	Servo5_SetAngle(60);
	Delay_ms(100);
	Servo1_SetAngle(70);
}
void leg2_Straight(void)
{
	Servo6_SetAngle(120);
	Delay_ms(100);
	Servo2_SetAngle(110);
}
void leg3_Straight(void)
{
	Servo7_SetAngle(50);
	Delay_ms(100);
	Servo3_SetAngle(70);
}
//以上为单腿伸直

void leg0_ATCW(void)
{
	Servo0_SetAngle(85);
	Delay_ms(10);
	Servo4_SetAngle(145);
	Delay_ms(100);
	Servo0_SetAngle(55);
}
void leg1_ATCW(void)
{
	Servo1_SetAngle(75);
	Delay_ms(10);
	Servo5_SetAngle(105);
	Delay_ms(100);
	Servo1_SetAngle(105);
}
void leg2_ATCW(void)
{
	Servo2_SetAngle(100);
	Delay_ms(10);
	Servo6_SetAngle(165);
	Delay_ms(100);
	Servo2_SetAngle(70);
}
void leg3_ATCW(void)
{
	Servo3_SetAngle(75);
	Delay_ms(10);
	Servo7_SetAngle(100);
	Delay_ms(100);
	Servo3_SetAngle(105);
}
//以上为单足逆时针迈进

void leg0_CW(void)
{
	Servo0_SetAngle(85);
	Delay_ms(10);
	Servo4_SetAngle(62);
	Delay_ms(100);
	Servo0_SetAngle(55);
}
void leg1_CW(void)
{
	Servo1_SetAngle(75);
	Delay_ms(10);
	Servo5_SetAngle(25);
	Delay_ms(100);
	Servo1_SetAngle(105);
}
void leg2_CW(void)
{
	Servo2_SetAngle(100);
	Delay_ms(10);
	Servo6_SetAngle(75);
	Delay_ms(100);
	Servo2_SetAngle(70);
}
void leg3_CW(void)
{
	Servo3_SetAngle(75);
	Delay_ms(10);
	Servo7_SetAngle(12);
	Delay_ms(100);
	Servo3_SetAngle(105);
}
//以上为单足顺时针迈进

